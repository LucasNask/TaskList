package br.com.udemy.tasks.model;

public enum TaskState {
    INSERT,
    DOING,
    DONE
}
