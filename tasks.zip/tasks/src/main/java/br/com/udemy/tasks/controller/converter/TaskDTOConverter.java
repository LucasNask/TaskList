package br.com.udemy.tasks.controller.converter;

import br.com.udemy.tasks.controller.dto.TaskDTO;
import br.com.udemy.tasks.model.Task;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class TaskDTOConverter {

    public TaskDTO convert(Task task){
        return Optional.ofNullable(task)
                .map(source -> {
                    TaskDTO taskDTO = new TaskDTO();
                    taskDTO.setDescription(task.getDescription());
                    taskDTO.setTitle(task.getTitle());
                    taskDTO.setPriority(task.getPriority());
                    taskDTO.setState(task.getState());
                    return taskDTO;
                }).orElse(null);
    }

    public Task convert(TaskDTO taskDTO){
        return Optional.ofNullable(taskDTO)
                .map(source -> Task.builder()
                        .withTitle(taskDTO.getTitle())
                        .withDescription(taskDTO.getDescription())
                        .withPriority(taskDTO.getPriority())
                        .withState(taskDTO.getState())
                        .build())
                .orElse(null);
    }

    public List<TaskDTO> convertList(List<Task> taskList){
        return Optional.ofNullable(taskList)
                .map(array -> array.stream().map(this::convert).collect(Collectors.toList()))
                .orElse(new ArrayList<>());
    }

}
